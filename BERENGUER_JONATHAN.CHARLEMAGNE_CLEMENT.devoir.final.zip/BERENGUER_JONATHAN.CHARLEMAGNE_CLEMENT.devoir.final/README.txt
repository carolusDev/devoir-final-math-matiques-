Ce qui manque à notre programme pour être fonctionnel c'est au final seulement quelques étapes :
-> mettre les nombres dans une liste pour chaque couleur
-> ajouter la liste au début du script initial pour remplacer les valeurs des couleurs de la photo
-> afficher la photo

Concernant le déchiffrement, nous avons voulu essayer de créer notre propre système, nous étions un peu ambitieux visiblement !
La clée de déchiffrement n'en n'ai pas vraiment une, et l'utilsition de valeurs aléatoires à complexifié les choses.
Nous pensons finir par y arriver mais par manque de temps nous vous rendons celà.
