from random import* #importation de la blibliothèque permettant un tirage aléatoire

print("partie chiffrement")
#ici un chiffre notre chaine de caractères
words_user = 'Hello World'
print(words_user)
words_user_size = len(words_user)#on la mesure

#on isole chaque lettre puis on la place dans une liste
step_1 = words_user.split()
step_2 = "".join(words_user.split())
step_3 = list("".join(words_user.split()))
print(step_3)
#on cherche à ajouter un grain de sel au début de la chaine de caractères
value_random_0 = (words_user_size) - (words_user_size)
add_values_0 = step_3.insert(value_random_0, 756701)
#l'utilisation de valeurs n'était pas malin puisque pour la clé de déchiffrement il fallait retomber sur les mêmes valeurs pour lire le message ...
value_random_1 = (words_user_size % 2)
x_0 = randint(1, 4)
x_1 = x_0 * 2
add_values_1 = step_3.insert(value_random_1, x_1)
print(step_3)

y = randint(1, 9)
z = randint(1, 9)
w = randint(1, 9)
yzw = [y , z , w]
value_random_2 = (words_user_size) + 1
add_values_2 = step_3.insert(value_random_2, yzw)
print(step_3)

print("partie déchiffrement")

for i in range(2):
    del step_3[0]
del step_3[10]
print(step_3)
