#coding:utf-8   #encodage du logiciel, utf 8 étant pour les langues latines
from tkinter import *   #importation de la bibliothèque tkinter
from PIL import Image, ImageTk #bibliothèque permettant de gérer les images
from random import*

i = 0 #on initialise i

window=Tk() #création de la fenêtre

window.title("Super logciel ! ")   #caractéristiques de la fenêtre : nom, taille, couleur de fond.
window.maxsize(600, 600)
window.minsize(600, 600)
window.configure(bg = 'black') #couleur de fond noire
#voici la chaine de caractère que nous allons dissimuler dans l'image, hello world sera placé dans chaque liste rgb
words_user = "Hello World !"
#on charge l'image, puis on sépare le rouge, le vert et le bleu, le  "a" est nécessaire pour éviter au script de planter
words_user_bin = words_user.encode()
Load = Image.open("panda.png")
r, g, b, a = Load.split()

#voici la liste de couleur rouge, on récupère les données, et on extrait une partie des valeures pour que se soit plus facile à exploiter
# on convertit celles ci en binaire, on a laissé les print pour que vous puissiez suivre les actions du script depuis l'invite de commandes

redList = list(r.getdata())
images_values_red_court = redList[0:14]
for i in images_values_red_court:
    bin_values_red = bin(i)[2:]
    print(" valeurs rouges binaires -> ", bin_values_red)
for i in words_user_bin:
    bin_user_0 = bin(i)[2:]
    replace_0 = bin_values_red.replace(bin_values_red, bin_user_0)
    print(" valeurs rouges remplacées -> ", replace_0)
    i = 0
#on initialise nos variables et on mesure la longueur de la chaine de caractères
    value_user_0 = int(replace_0)
    user_str_0 = str(value_user_0)
    user_size_0 = len(user_str_0)
    element_0 = 0
    nombre_decimal_0 = 0
# tant que i est inférieur à la longeur de la chaine de caractères, on continue la conversion
    while (i < user_size_0):
        element_0 = int(user_str_0[i])
        if (element_0 != 0 and element_0 != 1):
            print("bin checked")
            sys.exit()
        else:
            nombre_decimal_0 = (nombre_decimal_0 * 2) + element_0
            i = i + 1
    print ("nombre decimal équivalent est -> ", nombre_decimal_0)
    print(nombre_decimal_0)
#idem pour le vert et le bleu
greenList = list(g.getdata())
images_values_green_court = greenList[0:14]
for i in images_values_green_court:
    bin_values_green = bin(i)[2:]
    print(" valeurs vertes binaires -> ", bin_values_green)
for i in words_user_bin:
    bin_user_1 = bin(i)[2:]
    replace_1 = bin_values_red.replace(bin_values_red, bin_user_1)
    print(" valeurs vertes remplacées -> ", replace_1)
    i = 0
    value_user_1 = int(replace_1)
    user_str_1 = str(value_user_1)
    user_size_1 = len(user_str_1)
    element_1 = 0
    nombre_decimal_1 = 0
    while (i < user_size_1):
        element_1 = int(user_str_1[i])
        if (element_1 != 0 and element_1 != 1):
            print("bin checked")
            sys.exit()
        else:
            nombre_decimal_1 = (nombre_decimal_1 * 2) + element_1
            i = i + 1
    print ("nombre decimal équivalent est -> ", nombre_decimal_1)

blueList = list(b.getdata())
images_values_blue_court = blueList[0:14]
for i in images_values_blue_court:
    bin_values_blue = bin(i)[2:]
    print(" valeurs bleues binaires -> ", bin_values_blue)
for i in words_user_bin:
    bin_user_2 = bin(i)[2:]
    replace_2 = bin_values_red.replace(bin_values_red, bin_user_2)
    print(" valeurs bleues remplacées -> ", replace_2)
    i = 0
    value_user_2 = int(replace_2)
    user_str_2 = str(value_user_2)
    user_size_2 = len(user_str_2)
    element_2 = 0
    nombre_decimal_2 = 0
    while (i < user_size_2):
        element_2 = int(user_str_2[i])
        if (element_2 != 0 and element_2 != 1):
            print("bin checked")
            sys.exit()
        else:
            nombre_decimal_2 = (nombre_decimal_2 * 2) + element_2
            i = i + 1
    print ("nombre decimal équivalent est -> ", nombre_decimal_2)
# affichage de l'image et du texte avec tkinter
photo = ImageTk.PhotoImage(Load)
titre_image = Label(window, font = ("Helvetica", 10), text = "Image originale : ")
titre_image.place(x = 250, y = 20)
label_image = Label(window, image = photo)
label_image.place(x = 150, y = 50)
titre_image = Label(window, font = ("Helvetica", 10), text = "Image avec le texte caché : ")
titre_image.place(x = 210, y = 250)

window.mainloop()   #affichage de la fenêtre
